"use strict";

// Declare app level module which depends on views, and core components
angular
  .module("iDevApp", [
    "app.templates",
    "ui.router",
    // "ngResource",
    // "ui.bootstrap",
    // "ngFileUpload",
    // "ui-notification",
    // "ngAnimate",
    // "ngMessages",
    "core.user",
    "core",
    "core.admin",
    "core.admin.routes",
    "core.routes",
    "users.routes",
    "users.admin.services",
    "users.admin.routes",
    "users.admin",
    "users",
    "users.services",
    //'articles',
    //'articles.admin',
    //''
    //'oc.lazyLoad',
  ])
  .controller("IDevController", IDevController)
  .config(bootstrapConfig);

IDevController.$inject = ["$location", "$state", "$scope"];

function IDevController($location, $state, $scope) {
  var vm = this;
}
// Angular-ui-notification configuration
angular.module("ui-notification").config(function (NotificationProvider) {
  NotificationProvider.setOptions({
    delay: 2000,
    startTop: 20,
    startRight: 10,
    verticalSpacing: 20,
    horizontalSpacing: 20,
    positionX: "right",
    positionY: "bottom",
  });
});
bootstrapConfig.$inject = [
  "$compileProvider",
  "$locationProvider",
  "$httpProvider",
  "$logProvider",
];

function bootstrapConfig(
  $compileProvider,
  $locationProvider,
  $httpProvider,
  $logProvider
) {
  $locationProvider
    .html5Mode({
      enabled: true,
      requireBase: false,
    })
    .hashPrefix("!");

  $httpProvider.interceptors.push("authInterceptor");

  // Disable debug data for production environment
  // @link https://docs.angularjs.org/guide/production
  $compileProvider.debugInfoEnabled(
    process.env.NODE_ENV !== "production"
  );
  $logProvider.debugEnabled(process.env.NODE_ENV !== "production");
}

// Then define the init function for starting up the application
angular.element(document).ready(init);

function init() {
  // Fixing facebook bug with redirect
  if (window.location.hash && window.location.hash === "#_=_") {
    if (window.history && history.pushState) {
      window.history.pushState("", document.title, window.location.pathname);
    } else {
      // Prevent scrolling by storing the page's current scroll offset
      var scroll = {
        top: document.body.scrollTop,
        left: document.body.scrollLeft,
      };
      window.location.hash = "";
      // Restore the scroll offset, should be flicker free
      document.body.scrollTop = scroll.top;
      document.body.scrollLeft = scroll.left;
    }
  }

  // Then init the app
  angular.bootstrap(document, "iDevApp");
}
