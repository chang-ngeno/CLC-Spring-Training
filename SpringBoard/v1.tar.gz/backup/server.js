'use strict';

/**
 * Module dependencies.
 */
var app = require('./app/js/config/lib/app');
var server = app.start();
