"use strict";

var gulp = require("gulp");
var concat = require("gulp-concat");
var refresh = require("gulp-livereload");
var client = require("tiny-lr")();
var nodemon = require("gulp-nodemon");
var sass = require("gulp-sass");
var del = require("del");
var concat = require("gulp-concat");
var htmlmin = require("gulp-htmlmin");
var uglify = require("gulp-uglify");
var cssmin = require("gulp-minify-css");
var bower = require("main-bower-files");
var runSequence = require("run-sequence");
var templateCache = require("gulp-angular-templatecache");

var lrPort = 35728; // Livereload port

// Paths to source files/folders to be used in tasks
var paths = {
  scripts: ["!app/lib/**/*.js", "app/**/*.js"],
  vendorScripts: ["app/lib/**/*.js"],
  views: ["!app/lib/*.html","!app/index.html", "app/**/*.html"],
  styles: {
    css: ["!app/lib/**/*.css", "app/css/*.css"],
    sass: ["app/styles/sass/*.sass", "app/**/*.sass"],
    dest: "app/styles",
    vendor: "app/lib/**/*.css",
  },
  fonts: ["app/css/fonts/*.*", "app/lib/font-awesome/fonts/*.*"],
  html: "index.html",
  templates: "app/views/*.html",
  images: "app/img/**.*",
  favicon: "app/img/favicon.ico",
};

// Paths to destination files/folders which will be updated during tasks
var dist = {
  path: "dist",
  views: "dist/views",
  scripts: "dist/js",
  styles: "dist/css",
  images: "dist/images",
  fonts: "dist/css/fonts",
};

// Set NODE_ENV to 'test'
gulp.task("env:test", function (done) {
  process.env.NODE_ENV = "test";
  return done();
});

// Set NODE_ENV to 'development'
gulp.task("env:dev", function (done) {
  process.env.NODE_ENV = "development";
  return done();
});

// Set NODE_ENV to 'production'
gulp.task("env:prod", function (done) {
  process.env.NODE_ENV = "production";
  return done();
});

gulp.task("serve", function () {
  nodemon({ script: "app.js", ignore: ["node_modules/**/*.js"] });
});

gulp.task("live", async function () {
  client.listen(lrPort, function (err) {
    if (err) return console.error(err);
  });
});

gulp.task("watch", function () {
  gulp.watch(paths.styles.sass, ["styles"]);
  gulp.watch(paths.templates, ["templates"]);
  gulp.watch(paths.scripts, ["scripts"]);
});

gulp.task("refresh", function () {
  refresh(client);
});

gulp.task("clean", function (cb) {
  return del(dist.path, cb);
});

gulp.task("html", async function () {
  return gulp
    .src(paths.html)
    .pipe(
      htmlmin({
        collapseWhitespace: true,
        removeComments: true,
      })
    )
    .pipe(gulp.dest(dist.path))
    .pipe(refresh(client));
});

gulp.task("scripts", async function () {
  return gulp
    .src([
      // NOTE: be aware of dependencies between files when setting load order
      "app/js/modules/app.module.js",
      "app/js/modules/users.admin.routes.module.js",
      "app/js/modules/users.admin.services.module.js",
      "app/js/modules/core.module.js",
      "app/js/modules/core.admin.module.js",
      "app/js/modules/user.module.js",
      "app/js/modules/users.admin.module.js",
      "app/js/modules/users.module.js",
      "app/js/modules/users.routes.module.js",
      "app/js/modules/users.services.module.js",
      "app/js/modules/core.admin.routes.module.js",
      "app/js/modules/core.routes.module.js",
      "app/js/services/*.js",
      "app/js/directives/*.js",
      "app/js/controllers/*.js",
      "app/js/config/routes/*.js",
      "app/js/config/menus/*.js",
      //"src/client/app/admin/index.js",
      //"src/client/app/admin/**/*.js",
    ])
    .pipe(uglify({ mangle: false }).on("error", console.error))
    .pipe(concat("app.js"))
    .pipe(gulp.dest(dist.scripts))
    .pipe(refresh(client));
});

gulp.task("scripts:vendor", async function () {
  return gulp
    .src(bower({ filter: /\.js$/ }))
    .pipe(concat("vendor.js"))
    .pipe(uglify())
    .pipe(gulp.dest(dist.scripts))
    .pipe(refresh(client));
});

gulp.task("styles", async function () {
  return gulp
    .src(paths.styles.sass)
    .pipe(sass())
    .pipe(cssmin())
    .pipe(concat("styles.css"))
    .pipe(gulp.dest(dist.styles))
    .pipe(refresh(client));
});

gulp.task("styles:vendor", async function () {
  return gulp
    .src(paths.styles.vendor)
    .pipe(concat("vendor.css"))
    .pipe(uglify().on("error", console.error))
    .pipe(gulp.dest(dist.styles))
    .pipe(refresh(client));
});

// AngularJS-specific task for compiling templates into angular modules
gulp.task("templates", async function () {
  return gulp
    .src(paths.templates)
    .pipe(
      htmlmin({
        collapseWhitespace: true,
        removeComments: true,
      })
    )
    .pipe(
      templateCache({
        module: "app.templates", // Set module name. Import usage: angular.module('my-app', ['app.templates'])
        standalone: true,
        transformUrl: function (url) {
          return "/views" + url; // Set path to template
        },
      })
    )
    .pipe(gulp.dest(dist.scripts))
    .pipe(refresh(client));
});
gulp.task("view:templates", async function () {
  return gulp
    .src(paths.templates)
    .pipe(
      htmlmin({
        collapseWhitespace: true,
        removeComments: true,
      })
    )
    .pipe(gulp.dest(dist.views))
    .pipe(refresh(client));
});

gulp.task("images", async function () {
  return gulp.src(paths.images).pipe(gulp.dest(dist.images));
});

gulp.task("fonts", async function () {
  return gulp.src(paths.fonts).pipe(gulp.dest(dist.fonts));
});

gulp.task("favicon", async function () {
  return gulp
    .src(paths.favicon, { allowEmpty: true })
    .pipe(gulp.dest(dist.path));
});

gulp.task(
  "build",
  gulp.series(
    "html",
    "view:templates",
    "scripts",
    "scripts:vendor",
    "styles",
    "styles:vendor",
    "templates",
    "images",
    "fonts",
    "favicon"
  )
);

/* gulp.task('default', function() {
  gulp.parallel('clean', 'build', 'live', 'serve', 'watch');
}); */
gulp.task(
  "default",
  gulp.series("clean", "build", "live", "serve", "watch"),
  (cb) => {
    cb();
  }
);

gulp.task(
  "run:dev",
  gulp.series("clean","env:dev", "build", "live", "serve", "watch"),
  (cb) => {
    cb();
  }
);

gulp.task(
  "run:prod",
  gulp.series("clean","env:prod" ,"build", "live", "serve", "watch"),
  (cb) => {
    cb();
  }
);

process.once("SIGINT", function () {
  process.exit(0);
});
