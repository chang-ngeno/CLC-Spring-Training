"use strict";

// Define the `core` module
angular.module("core.routes", ["app.templates", "ui.router"]);
