"use strict";

// Define the `core` module
angular.module("core.admin", ["app.templates", "core"]);
