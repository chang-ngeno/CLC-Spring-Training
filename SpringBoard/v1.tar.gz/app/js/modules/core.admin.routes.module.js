"use strict";

// Define the `core` module
angular.module("core.admin.routes", ["app.templates", "ui.router"]);
