"use strict";

// Define the `core` module
angular.module("core", ["app.templates", "core.user"]);
