"use strict";

angular.module("users.routes", ["app.templates", "ui.router", "core.routes"]);
