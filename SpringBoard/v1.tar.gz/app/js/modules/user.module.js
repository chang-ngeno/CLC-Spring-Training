"use strict";

// Define the `core.user` module
angular.module("core.user", ["app.templates", "ngResource"]);
