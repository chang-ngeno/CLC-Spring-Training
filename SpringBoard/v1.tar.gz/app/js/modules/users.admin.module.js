"use strict";

angular.module("users.admin", ["app.templates"]);
