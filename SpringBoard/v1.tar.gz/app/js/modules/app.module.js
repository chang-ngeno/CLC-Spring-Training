"use strict";

// Declare app level module which depends on views, and core components
angular
  .module("iDevApp", [
    "app.templates",
    "ui.router",
    "core.user",
    "core",
    "core.admin",
    "core.admin.routes",
    "core.routes",
    "users.routes",
    "users.admin.services",
    "users.admin.routes",
    "users.admin",
    "users",
    "users.services",
    //'articles',
    //'articles.admin',
    //''
    //'oc.lazyLoad',
  ])
  .controller("IDevController", IDevController);

IDevController.$inject = ["$location", "$state", "$scope"];

function IDevController($location, $state, $scope) {
  var vm = this;
  $state.go("home");
}
