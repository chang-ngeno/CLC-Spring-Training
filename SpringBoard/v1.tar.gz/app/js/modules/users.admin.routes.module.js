"use strict";

angular.module("users.admin.routes", [
  "app.templates",
  "ui.router",
  "core.routes",
  "users.admin.services",
]);
