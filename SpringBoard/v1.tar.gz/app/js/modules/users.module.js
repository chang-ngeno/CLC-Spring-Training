"use strict";

angular.module("users", [
  "app.templates",
  "ui.router",
  "users.admin",
  "users.admin.services",
  "users.services",
  "users.routes",
  "users.admin.routes",
]);
