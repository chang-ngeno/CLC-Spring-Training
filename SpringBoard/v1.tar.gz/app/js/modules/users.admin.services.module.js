"use strict";

angular.module("users.admin.services", ["app.templates"]);
