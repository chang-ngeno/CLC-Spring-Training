"use strict";

angular.module("users.services", ["app.templates"]);
