(function () {
  "use strict";

  // Setting up route
  angular.module("users.admin.routes").config(routeConfig);

  routeConfig.$inject = ["$stateProvider"];

  function routeConfig($stateProvider) {
    $stateProvider
      .state("admin.users", {
        url: "/users",
        templateUrl: "app/list-users.client.view.html",
        controller: "UserListController",
        controllerAs: "vm",
      })
      .state("admin.user", {
        url: "/users/:userId",
        templateUrl: "app/view-user.client.view.html",
        controller: "UserController",
        controllerAs: "vm",
        resolve: {
          userResolve: getUser,
        },
        data: {
          pageTitle: "{{ userResolve.displayName }}",
        },
      })
      .state("admin.user-edit", {
        url: "/users/:userId/edit",
        templateUrl: "app/edit-user.client.view.html",
        controller: "UserController",
        controllerAs: "vm",
        resolve: {
          userResolve: getUser,
        },
        data: {
          pageTitle: "{{ userResolve.displayName }}",
        },
      });

    getUser.$inject = ["$stateParams", "AdminService"];

    function getUser($stateParams, AdminService) {
      return AdminService.get({
        userId: $stateParams.userId,
      }).$promise;
    }
  }
})();
