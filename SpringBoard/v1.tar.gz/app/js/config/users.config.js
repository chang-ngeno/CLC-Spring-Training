// 'use strict';

// // Setting up route
// angular
//     .module('users')
//     .config(routeConfig);

// //convert this to $routeProvider
// routeConfig.$inject = ['$stateProvider'];

// function routeConfig($stateProvider) {
//     // Users state routing
//     $stateProvider
//         .state('settings', {
//             abstract: true,
//             url: '/settings',
//             templateUrl: '/app/views/settings.client.view.html',
//             controller: 'SettingsController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load([
//                         '/app/controllers/settings/settings.client.controller.js',
//                         '/app/services/authentication.client.service.js'
//                     ]);
//             },
//             data: {
//                 roles: ['user', 'admin']
//             }
//         })
//         .state('settings.profile', {
//             url: '/profile',
//             templateUrl: '/app/views/settings/edit-profile.client.view.html',
//             controller: 'EditProfileController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load('/app/controllers/settings/edit-profile.client.controller.js');
//             },
//             data: {
//                 pageTitle: 'Settings'
//             }
//         })
//         .state('settings.password', {
//             url: '/password',
//             templateUrl: '/app/views/settings/change-password.client.view.html',
//             controller: 'ChangePasswordController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load('/app/controllers/settings/change-password.client.controller.js');
//             },
//             data: {
//                 pageTitle: 'Settings password'
//             }
//         })
//         .state('settings.accounts', {
//             url: '/accounts',
//             templateUrl: '/app/views/settings/manage-social-accounts.client.view.html',
//             controller: 'SocialAccountsController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load('/app/controllers/settings/manage-social-accounts.client.controller.js');
//             },
//             data: {
//                 pageTitle: 'Settings accounts'
//             }
//         })
//         .state('settings.picture', {
//             url: '/picture',
//             templateUrl: '/app/views/settings/change-profile-picture.client.view.html',
//             controller: 'ChangeProfilePictureController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load('/app/controllers/settings/change-profile-picture.client.controller.js');
//             },
//             data: {
//                 pageTitle: 'Settings picture'
//             }
//         })
//         .state('authentication', {
//             abstract: true,
//             url: '/authentication',
//             templateUrl: '/app/views/authentication/authentication.client.view.html',
//             controller: 'AuthenticationController',
//             controllerAs: 'vm',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load([
//                         '/app/controllers/authentication.client.controller.js',
//                         '/app/services/users.client.service.js',
//                         '/app/services/authentication.client.service.js',
//                         '/app/services/password-validator.client.service.js'
//                     ]);
//             }
//         })
//         .state('authentication.signup', {
//             url: '/signup',
//             templateUrl: '/app/views/authentication/signup.client.view.html',
//             controller: 'AuthenticationController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load([
//                         '/users/controllers/authentication.client.controller.js',
//                         '/users/services/users.client.service.js',
//                         '/users/services/authentication.client.service.js',
//                         '/users/services/password-validator.client.service.js'
//                     ]);
//             },
//             data: {
//                 pageTitle: 'Signup'
//             }
//         })
//         .state('authentication.signin', {
//             url: '/signin?err',
//             templateUrl: '/users/views/authentication/signin.client.view.html',
//             controller: 'AuthenticationController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load([
//                         '/users/controllers/authentication.client.controller.js',
//                         '/users/services/users.client.service.js',
//                         '/users/services/authentication.client.service.js',
//                         '/users/services/password-validator.client.service.js'
//                     ]);
//             },
//             data: {
//                 pageTitle: 'Signin'
//             }
//         })
//         .state('password', {
//             abstract: true,
//             url: '/password',
//             template: '<ui-view/>',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load([
//                         '/users/controllers/password.client.controller.js',
//                         '/users/services/password-validator.client.service.js'
//                     ]);
//             }
//         })
//         .state('password.forgot', {
//             url: '/forgot',
//             templateUrl: '/users/views/password/forgot-password.client.view.html',
//             controller: 'PasswordController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load([
//                         '/users/controllers/password.client.controller.js',
//                         '/users/services/password-validator.client.service.js'
//                     ]);
//             },
//             data: {
//                 pageTitle: 'Password forgot'
//             }
//         })
//         .state('password.reset', {
//             abstract: true,
//             url: '/reset',
//             template: '<ui-view/>',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load([
//                         '/users/controllers/password.client.controller.js',
//                         '/users/services/password-validator.client.service.js'
//                     ]);
//             },
//         })
//         .state('password.reset.invalid', {
//             url: '/invalid',
//             templateUrl: '/users/views/password/reset-password-invalid.client.view.html',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load([
//                         '/users/controllers/password.client.controller.js',
//                         '/users/services/password-validator.client.service.js'
//                     ]);
//             },
//             data: {
//                 pageTitle: 'Password reset invalid'
//             }
//         })
//         .state('password.reset.success', {
//             url: '/success',
//             templateUrl: '/users/views/password/reset-password-success.client.view.html',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load('/users/controllers/password.client.controller.js');
//             },
//             data: {
//                 pageTitle: 'Password reset success'
//             }
//         })
//         .state('password.reset.form', {
//             url: '/:token',
//             templateUrl: '/users/views/password/reset-password.client.view.html',
//             controller: 'PasswordController',
//             controllerAs: 'vm',
//             lazyLoad: function ($transition$) {
//                 return $transition$.injector().get('$ocLazyLoad')
//                     .load('/users/controllers/password.client.controller.js');
//             },
//             data: {
//                 pageTitle: 'Password reset form'
//             }
//         });
// }
