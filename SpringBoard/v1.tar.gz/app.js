'use strict';

/**
 * Module dependencies.
 */
let path = require('path');
let express = require('express');

let PORT = 3500;
let distDir = path.resolve(__dirname, './dist');

let app = express();

app.use(express.static(distDir)); // Setup static folder

app.get('*', function (req, res) {
  let mainTemplateFile = path.join(distDir, 'index.html'); // Path to main app template
  res.sendFile(mainTemplateFile);
});

app.listen(PORT);
console.log('App started on port:' + PORT);
